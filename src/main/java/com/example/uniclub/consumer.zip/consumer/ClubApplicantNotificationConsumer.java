package com.example.uniclub.consumer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ClubApplicantNotificationConsumer {

//    @RabbitListener(queues = RabbitMQConfig.CLUB_APP_QUEUE)
//    public void handleClubApplicantStatus(ClubApplicantMessage message) {
//        log.info("📩 Nhận được message: {}", message);
//    }
}
