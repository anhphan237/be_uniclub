//package com.example.uniclub.enums;
//
//public enum ApplicationSourceTypeEnum {
//    ONLINE,   // Sinh viên nộp đơn qua hệ thống
//    OFFLINE   // Nhà trường nhập đơn đã duyệt thủ công
//}
