package com.example.uniclub.enums;

public enum MemberApplicationStatusEnum {
    PENDING,
    INTERVIEWING,
    APPROVED,
    REJECTED,
    EXPIRED
}
