package com.example.uniclub.enums;

public enum PointRequestStatusEnum {
    PENDING,
    APPROVED,
    REJECTED
}
