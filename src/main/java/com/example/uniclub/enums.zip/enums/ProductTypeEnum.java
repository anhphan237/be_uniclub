package com.example.uniclub.enums;

public enum ProductTypeEnum {
    CLUB_ITEM,     // hàng dài hạn trong kho CLB
    EVENT_ITEM     // hàng ngắn hạn chỉ xuất hiện trong sự kiện
}
