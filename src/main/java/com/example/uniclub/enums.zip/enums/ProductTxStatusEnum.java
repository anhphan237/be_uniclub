package com.example.uniclub.enums;

import lombok.Getter;

@Getter
public enum ProductTxStatusEnum {
    RESERVED, DELIVERED, CANCELLED

}

