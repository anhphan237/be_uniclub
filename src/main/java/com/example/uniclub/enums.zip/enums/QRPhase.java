package com.example.uniclub.enums;

public enum QRPhase {
    START,   // Check-in đầu buổi
    MID,     // Check giữa buổi
    END      // Check-out cuối buổi
}
