package com.example.uniclub.enums;

public enum MemberApplyStatusEnum {
    PENDING,
    APPROVED,
    REJECTED
}
