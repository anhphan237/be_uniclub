package com.example.uniclub.enums;

public enum RedeemStatusEnum {
    PENDING, DELIVERED, CANCELLED, EXPIRED
}
