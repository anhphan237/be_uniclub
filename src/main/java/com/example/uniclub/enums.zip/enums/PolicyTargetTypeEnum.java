package com.example.uniclub.enums;

public enum PolicyTargetTypeEnum {
    CLUB,
    MEMBER
}
