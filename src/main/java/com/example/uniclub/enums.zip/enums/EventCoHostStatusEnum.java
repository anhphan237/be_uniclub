package com.example.uniclub.enums;

public enum EventCoHostStatusEnum {
    PENDING,
    APPROVED,
    REJECTED
}