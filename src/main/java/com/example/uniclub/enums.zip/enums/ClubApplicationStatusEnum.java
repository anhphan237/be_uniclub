package com.example.uniclub.enums;

public enum ClubApplicationStatusEnum {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETE
}
