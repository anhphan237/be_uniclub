package com.example.uniclub.enums;

public enum ClubRoleEnum {
    LEADER,        // Chủ nhiệm
    VICE_LEADER,   // Phó chủ nhiệm
    STAFF,         // Nhân sự hỗ trợ
    MEMBER         // Thành viên thường
}
