//
//package com.example.uniclub.enums;
//
//public enum ClubTypeEnum {
//    ACADEMIC,     // Học thuật
//    ART,          // Nghệ thuật
//    SPORT,        // Thể thao
//    VOLUNTEER,    // Tình nguyện
//    BUSINESS      // Kinh doanh / Khởi nghiệp
//}
