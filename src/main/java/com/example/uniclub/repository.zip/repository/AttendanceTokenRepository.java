package com.example.uniclub.repository;

import com.example.uniclub.entity.AttendanceToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AttendanceTokenRepository extends JpaRepository<AttendanceToken, Long> {
    Optional<AttendanceToken> findByRawToken(String token);
}


