package com.example.uniclub.repository;

import com.example.uniclub.entity.ProductCategory;
import com.example.uniclub.entity.ProductCategoryId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductCategoryRepository extends JpaRepository<ProductCategory, ProductCategoryId> {}
