package com.example.uniclub.repository;

import com.example.uniclub.entity.Return;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReturnRepository extends JpaRepository<Return, Long> {}
