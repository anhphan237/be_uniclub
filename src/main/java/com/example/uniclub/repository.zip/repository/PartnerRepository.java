package com.example.uniclub.repository;

import com.example.uniclub.entity.Partner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartnerRepository extends JpaRepository<Partner, Long> {}
