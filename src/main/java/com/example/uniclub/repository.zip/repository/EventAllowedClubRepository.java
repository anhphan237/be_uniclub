package com.example.uniclub.repository;

import com.example.uniclub.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventAllowedClubRepository extends JpaRepository<EventAllowedClub, Long> {
    boolean existsByEventAndClub(Event event, Club club);
}
