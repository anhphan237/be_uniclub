package com.example.uniclub.service;

public interface ProductTagAutoService {

    void updateDynamicTags();
}
