package com.example.uniclub.service;

public interface DeliverService {
    void deliver(Long staffMembershipId, Long redeemId);
}
