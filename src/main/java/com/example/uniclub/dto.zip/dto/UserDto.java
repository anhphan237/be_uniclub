package com.example.uniclub.dto;

import lombok.Data;

@Data
public class UserDto {
    private String name;
    private String email;
    private String phone;
}