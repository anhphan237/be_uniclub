//package com.example.uniclub.dto.request;
//
//import lombok.Data;
//
//@Data
//public class ClubFinalizeRequest {
//
//}
